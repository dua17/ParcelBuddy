<?php
// Include necessary model files
require_once('Models/DeliveryPoint.php');
require_once('Models/DeliveryPointSet.php');

// Start a new session
session_start();

// Create a new stdClass object to store view-related data
$view = new stdClass();
$view->pageTitle = '';

// Instantiate a DeliveryPointSet object
$deliveryPointSet = new DeliveryPointSet();

// Fetch all delivery points and store them in the view
$view->deliveryPointSet = $deliveryPointSet->fetchAll();
$view->currentPage = 0;
$view->totalPages = 0;


// Check if the form has been submitted using POST and if a search term is provided
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search']) && !empty($_POST['search'])) {
    $searchTerm = $_POST['search'];
    $orderBy = isset($_POST['orderBy']) ? $_POST['orderBy'] : 'id'; // Default order by ID

    // Check user type to determine which fetch method to use
    if ($_SESSION['usertype'] == "Manager") {
        $view->deliveryPointSet = $deliveryPointSet->fetchAllWithSearchAndOrder($searchTerm, $orderBy);
    } else {
        $view->deliveryPointSet = $deliveryPointSet->fetchAllForUserWithSearchAndOrder($searchTerm, $orderBy, $_SESSION['userId']);
    }
} else {
    // If no search term provided, fetch all records based on user type
    if ($_SESSION['usertype'] == "Manager") {
        $view->deliveryPointSet = $deliveryPointSet->fetchAll();
    } else {
        $view->deliveryPointSet = $deliveryPointSet->fetchAllForUser($_SESSION['userId']);
    }
}

// Apply pagination only if there are records to paginate
if (!empty($view->deliveryPointSet)) {
    $current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $records_per_page = 10; // You can change this as needed
    $offset = ($current_page - 1) * $records_per_page;
    $total_pages = ceil(count($view->deliveryPointSet) / $records_per_page);

    // Update view with pagination information
    $view->currentPage = $current_page;
    $view->totalPages = $total_pages;

    // Fetch records with pagination
    $view->deliveryPointSet = array_slice($view->deliveryPointSet, $offset, $records_per_page);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delivery_id']) && isset($_POST['new_status'])) {
    // Sanitize input
    $deliveryId = intval($_POST['delivery_id']);
    $newStatus = $_POST['new_status'];

    // Update delivery status in the database
    $success = $deliveryPointSet->updateStatus($deliveryId, $newStatus);

    if ($success) {
        // Optionally, you can redirect or display a success message here
        echo "Status updated successfully";
    } else {
        // Handle error, such as displaying an error message
        echo "Error updating status";
    }
}

// Include the view file for rendering
require_once('Views/deliverer.phtml');

