<?php

// Start or resume the session
session_start();

// Initialize the view object
$view = new stdClass();
$view->pageTitle = '';

// Include the LoginAuthentication class
require_once 'Models/LoginAuthentication.php';

// Instantiate the LoginAuthentication class
$authenticator = new LoginAuthentication();

// Check if the login button was pressed
if (isset($_POST['login'])) {
    // Get username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Authenticate the user using the LoginAuthentication class
    $authenticatedUser = $authenticator->authenticateUser($username, $password);

    // Check if authentication was successful
    if ($authenticatedUser != null) {
        // Create session variables to indicate successful login
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['usertype'] = $authenticatedUser->getUserTypeName();
        $_SESSION['userId'] = $authenticatedUser->getUserID();

        switch ($_SESSION['usertype']) {
            case 'manager':
                header('Location: manager.php'); // Replace 'manager_page.php' with the actual page for managers
                exit();
            case 'deliverer':
                header('Location: deliverer.php'); // Replace 'deliverer_page.php' with the actual page for deliverers
                exit();
            // Add more cases for other user types if needed
            default:
                // Redirect to index page by default
                header('Location: index.php');
                exit();
        }
    }
}

// Check if the logout button was pressed
    if (isset($_POST['logout'])) {
        // Destroy the session, effectively logging the user out
        session_destroy();

        // Set a property in the view to indicate successful logout
        header('Location: index.php');
        exit();
    }

// Check if the user is logged in
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
        // Set a property in the view to indicate logged in status
        $view->loggedIn = true;

        // Get the username from the session
        $view->username = $_SESSION['username'];
    }

// Check if the logout query parameter is present
    if (isset($_GET['logout'])) {
        // Destroy the session, effectively logging the user out
        session_destroy();

        // Set a property in the view to indicate successful logout
        $view->loggedOut = true;
    }

// Include the HTML template file for displaying the page content
    require_once('Views/index.phtml');


