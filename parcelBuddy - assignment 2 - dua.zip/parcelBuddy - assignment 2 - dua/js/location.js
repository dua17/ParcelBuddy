// Wait for the DOM to fully load before executing the script
document.addEventListener("DOMContentLoaded", function() {
    var showMapButton = document.getElementById("showMapButton");
    var hideMapButton = document.getElementById("hideMapButton");
    var mapDiv = document.getElementById("map");

    hideMapButton.addEventListener("click", function() {
        //hideMapButton.style.display = "none"; // Hide the "Hide Map" button
        showMapButton.style.display = "block"; // Show the "Show Map" button
        mapDiv.style.display = "none"; // Hide the map
    });

    //map is hideen until enabled button by user
    showMapButton.addEventListener("click", function() {
        //showMapButton.style.display = "none"; // Hide the button once clicked
        mapDiv.style.display = "block"; // Show the map

        // Initialise Leaflet map on 'map' element
        var myMap = L.map('map').setView([51.505, -0.09], 13);

        // Add OpenStreetMap tiles to the map
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(myMap);

        // icon for user's current poisition
        //unique from other markers so user can see distance etc
        var currentLocationIcon = new L.Icon({
            iconUrl: 'js/leaflet/images/marker-icon-2x.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        var showOnMapButtons = document.querySelectorAll('.show-on-map-btn');

        //allowing click enabled pop up as well as retrieval of co ords to plot markers on map
        showOnMapButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                // Retrieve the latitude and longitude data from the button's data attributes
                var lat = parseFloat(this.getAttribute('data-lat'));
                var lng = parseFloat(this.getAttribute('data-lng'));

                // Center the map on the corresponding delivery point
                myMap.setView([lat, lng], 13); // Assuming 'myMap' is your Leaflet map object
            });
        });


        // Select form elements for status update and prevent event bubbling to avoid triggering row click events so when user clicks update delivery the map's view doesn't go to that deliveries location
        var formElements = document.querySelectorAll('.delivery-point-row select[name="statusUpdate"], .delivery-point-row button[name="updateStatus"]');
        formElements.forEach(function (element) {
            element.addEventListener('click', function (event) {
                event.stopPropagation();
            });
        });

        // Check if geolocation is available in the browser
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
                var userLat = position.coords.latitude;
                var userLong = position.coords.longitude;

                // Center the map on the user's current position
                myMap.setView([userLat, userLong], 13);

                L.marker([userLat, userLong], {icon: currentLocationIcon}).addTo(myMap)
                    .bindPopup('This is your current location!').openPopup();
            });
        }

        // Call the function to display markers for parcels during map initialization
        displayMarkersForParcels();

        //displays the delivery points as markers on the map
        function displayMarkersForParcels() {

            //retrueves users input and requests server for input
            var xhr = new XMLHttpRequest();
            //retreeuve JSON data
            xhr.open('GET', 'location.php', true);
            xhr.send();

            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);

                    data.forEach(function (deliveryPoint) {
                        // Define a custom icon for the marker
                        var customIcon = L.icon({
                            iconUrl: 'images/delivery-location.png', // URL to the custom icon image
                            iconSize: [50, 50], // Size of the icon [width, height]
                            iconAnchor: [12, 41], // Point of the icon which will correspond to marker's location
                            popupAnchor: [1, -34] // Point from which the popup should open relative to the iconAnchor
                        });

                        // Create marker with custom icon
                        var marker = L.marker([deliveryPoint.lat, deliveryPoint.lng], { icon: customIcon }).addTo(myMap);

                        // Generate QR code HTML for the delivery point
                        // Construct popup content with QR code HTML
                        let popupContent = `
                    <div class="align-middle" style="max-width: 400px;">
                        <strong>DELIVERY ID: ${deliveryPoint.id} <br/></strong>
                        <strong>RECIPIENT: ${deliveryPoint.name} <br/></strong>
                        <strong>ADDRESS: </strong> ${deliveryPoint.address1} <br/>
                        <div id="qrcode${deliveryPoint.id}"></div>
                    </div>
                `;

                        // Bind popup with updated content to the marker
                        marker.bindPopup(popupContent, { closeButton: false });

                        marker.on('popupopen', function() {
                            new QRCode(document.getElementById("qrcode" + deliveryPoint.id), {
                                text: "http://sgc529.poseidon.salford.ac.uk/clientserver/deliverer.php?id=" + deliveryPoint.id,
                                width: 72,
                                height: 72,
                                colorDark : "#000000",
                                colorLight : "#ffffff",
                                correctLevel : QRCode.CorrectLevel.H
                            });
                        });

                        // creates new qr code
                        var qrCodeElement = document.createElement("div");
                        qrCodeElement.id = "qrcode" + deliveryPoint.id;
                        qrCodeElement.style.display = "none";
                        document.body.appendChild(qrCodeElement);
                        new QRCode(qrCodeElement, {
                            text: "deliverer.php?id=" + deliveryPoint.id,
                            width: 100,
                            height: 100
                        });
                    });
                }
            };
        }


    });
});
