//linking font awesome link for icon use
class FontLoader {
    constructor() {
        // Font Awesome CDN link & constructor
        this.fontAwesomeLink = document.createElement('link');
        this.fontAwesomeLink.rel = 'stylesheet';
        this.fontAwesomeLink.href = 'https://kit.fontawesome.com/7831d23184.js'; // Replace with the appropriate Font Awesome CDN link

        // Append the Font Awesome link to the head element
        document.head.appendChild(this.fontAwesomeLink);
    }
}

// creatinf an object of the FontLoader class to load Font Awesome
const fontLoader = new FontLoader();

function liveSearch() {
    console.log('liveSearch function called');

    // store and receive the ssearch element for further use
    var searchInput = document.getElementById('search');

    // Check if the search input element exists
    if (searchInput) {
        // Get the value from the search input
        var searchTerm = searchInput.value;

        // checks the search term isnt empty
        if (searchTerm.trim() !== '') {
            // Create a new XMLHttpRequest object
            var xhr = new XMLHttpRequest();

            // Configure the request
            xhr.open('GET', 'liveSearch.php?searchTerm=' + searchTerm, true);

            // Set up a callback function to handle the response
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    // Parse the JSON response
                    var response = JSON.parse(xhr.responseText);

                    // Call a function to update the UI with the search results
                    updateSearchResults(response);
                }
            };

            // Send the request
            xhr.send();
        } else {
            // If the search term is empty, clear the search results
            clearSearchResults();
        }
    } else {
        console.error('Element with ID "search" not found');
    }
}

// Add event listener only if the search input element exists
document.addEventListener('DOMContentLoaded', function () {
    var searchInput = document.getElementById('search');
    if (searchInput) {
        searchInput.addEventListener('keyup', liveSearch);
    } else {
        console.error('Element with ID "search" not found');
    }
});


//updates the ui as well as creates pagination to separate results
function updateSearchResults(results) {


    // Get the list element where search results will be displayed
    var resultList = document.getElementById('txtHint');

    // Clear any older search results
    resultList.innerHTML = '';

    // Checks if there are any results
    if (results.length > 0) {
        var currentPage = 1;
        var resultsPerPage = 5;
        var totalResults = results.length;
        var totalPages = Math.ceil(totalResults / resultsPerPage);

        function displayResultsForPage(page) {
            var startIndex = (page - 1) * resultsPerPage;
            var endIndex = Math.min(startIndex + resultsPerPage, totalResults);

            resultList.innerHTML = '';

            for (var i = startIndex; i < endIndex; i++) {
                var listItem = document.createElement('li');
                listItem.innerHTML = " ID: " + results[i].id + ", Name: " + results[i].name + " " + '<i class="fa-solid fa-map-pin" style="color: #bb0707;"></i>' + " at " + results[i].address1 + ', ' + results[i].postcode;
                resultList.appendChild(listItem);
            }
        }

        // Display results for the first page
        displayResultsForPage(currentPage);

        // Create buttons for pagination to allow user to look through more suggestions
        var prevButton = document.createElement('button');
        prevButton.innerHTML = '<i class="fa-solid fa-square-caret-left fa-lg"></i>';
        prevButton.classList.add('prev-button');
        prevButton.addEventListener('click', function() {
            if (currentPage > 1) {
                currentPage--;
                displayResultsForPage(currentPage);
                updatePaginationButtons();
            }
        });

        //allows the yser to move to the next block of sugesstions
        var nextButton = document.createElement('button');
        nextButton.innerHTML = '<i class="fa-solid fa-square-caret-right fa-lg"></i>';
        nextButton.classList.add('next-button');
        nextButton.addEventListener('click', function() {
            if (currentPage < totalPages) {
                currentPage++;
                displayResultsForPage(currentPage);
                updatePaginationButtons();
            }
        });

        // Function to update pagination buttons
        function updatePaginationButtons() {
            if (totalResults <= 5) {
                prevButton.style.display = 'none';
                nextButton.style.display = 'none';
                return;
            }

            prevButton.style.display = 'inline-block';
            nextButton.style.display = 'inline-block';

            prevButton.disabled = currentPage === 1;
            nextButton.disabled = currentPage === totalPages;
        }

        resultList.appendChild(prevButton);
        resultList.appendChild(nextButton);

        updatePaginationButtons();
    } else {
        var listItem = document.createElement('li');
        listItem.textContent = 'No results found';
        resultList.appendChild(listItem);
    }
}

// search is cleared in this function
function clearSearchResults() {
    // Get the list element where search results are displayed
    var resultList = document.getElementById('txtHint');

    // Clear the list
    resultList.innerHTML = '';
}

// Attach the liveSearch function to the input field's keyup event
document.getElementById('search').addEventListener('keyup', liveSearch);
